import json
import boto3
from PyPDF2 import PdfReader

s3_client = boto3.client('s3')
bucket_name = 'testbuckee'  

def read_pdf(s3_url):
    """Read content from a PDF file in S3 and return page-wise content."""
    bucket_name = s3_url.split('/')[2]
    key = '/'.join(s3_url.split('/')[3:])
    
    s3_object = s3_client.get_object(Bucket=bucket_name, Key=key)
    file_content = s3_object['Body'].read()

    tmp_file_path = '/tmp/tempfile.pdf'
    with open(tmp_file_path, 'wb') as temp_file:
        temp_file.write(file_content)

    reader = PdfReader(tmp_file_path)
    pages = [page.extract_text() for page in reader.pages]
    return pages

def lambda_handler(event, context):
    print("Event received:", event)

    document_data = event.get('document_data', {})
    file_name = document_data.get('file_name', '')
    file_path = document_data.get('file_path', '')

    print(f"File name: {file_name}, File path: {file_path}")  

    if not file_name or not file_path:
        print("Missing file_name or file_path.")
        return {
            'statusCode': 400,
            'body': json.dumps('Missing file name or file path.')
        }

    pages = read_pdf(file_path)
    print(f"Document has {len(pages)} pages.")

    pre_signed_urls = []  
    for i, page_content in enumerate(pages):
        object_key = f"chunked_files/{file_name}_page_{i + 1}.txt"
        print(f"Uploading page: {object_key}")

        try:
            metadata = {
                'original_file': file_name,
                'page_index': str(i + 1),
                'document_url': f"s3://{bucket_name}/{file_name}"
            }

            s3_client.put_object(
                Bucket=bucket_name,  
                Key=object_key,      
                Body=page_content,  
                Metadata=metadata    
            )
            print(f"Successfully uploaded page {i + 1}")

            pre_signed_url = s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': bucket_name, 'Key': object_key},
                ExpiresIn=3600  
            )
            pre_signed_urls.append({
                'page': i + 1,
                'url': pre_signed_url
            })

        except Exception as e:
            print(f"Error uploading page {i + 1}: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps(f'Error uploading page {i + 1}: {str(e)}')
            }

    urls_file_key = f"chunked_files/{file_name}_pre_signed_urls.json"
    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=urls_file_key,
            Body=json.dumps(pre_signed_urls),  
            ContentType='application/json',
            Metadata={'original_file': file_name}
        )
        print(f"Successfully uploaded pre-signed URLs file: {urls_file_key}")
    except Exception as e:
        print(f"Error uploading pre-signed URLs file: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error uploading pre-signed URLs file: {str(e)}')
        }

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Pages uploaded successfully with metadata.',
            'pre_signed_urls_file': f"s3://{bucket_name}/{urls_file_key}"  
        })
    }
